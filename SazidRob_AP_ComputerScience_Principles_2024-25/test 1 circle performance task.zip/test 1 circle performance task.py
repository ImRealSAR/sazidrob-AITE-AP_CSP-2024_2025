import turtle as trtl
wn = trtl.Screen()
painter = trtl.Turtle()
painter.shape("circle")
painter.speed(10000000)
painter.hideturtle()
color1 = "black"
color2 = "red"
painter.penup()

x = 0
for i in range(6):
    painter.color(color1)
    newColor = i * -20
    painter.goto(0, newColor)    
    painter.stamp()
    for e in range(6):
        painter.color(color2)
        painter.forward(20)
        painter.stamp()
        painter.penup()

for i in range(6):
    newX = i * -20  
    painter.goto(newX,160)
    painter.color(color1)
    painter.stamp()
    for e in range(6):
        painter.color(color2)
        painter.setheading(-90)
        painter.forward(20)
        painter.stamp()
        painter.penup()

    
wn.mainloop()
